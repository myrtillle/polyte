declare module '@react-native-picker/picker' {
    import { Picker } from 'react-native';
    export { Picker };
  }