declare module 'react-native-image-picker';
