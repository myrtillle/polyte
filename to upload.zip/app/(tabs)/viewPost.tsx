// ViewPostScreen.tsx
import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { RouteProp } from '@react-navigation/native';
import { RootStackParamList } from '../../types/navigation';
import { StackNavigationProp } from '@react-navigation/stack';

type ViewPostScreenRouteProp = RouteProp<RootStackParamList, 'ViewPost'>;
type ViewPostScreenNavigationProp = StackNavigationProp<RootStackParamList, 'ViewPost'>;

type Props = {
  route: ViewPostScreenRouteProp;
  navigation: ViewPostScreenNavigationProp;
};

const ViewPostScreen = ({ route }: Props) => {
  const { post } = route.params || {};

  if (!post) {
    return (
      <View style={styles.container}>
        <Text>No post data available.</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <Text style={styles.title}>{post.description}</Text>
      {/* Render other post details here */}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#fff',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
  },
});

export default ViewPostScreen;
